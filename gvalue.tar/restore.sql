--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.2
-- Dumped by pg_dump version 10.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP TABLE public.gvalues;
DROP TABLE public.distances;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: distances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE distances (
    point1 integer,
    point2 integer,
    distance numeric
);


ALTER TABLE distances OWNER TO postgres;

--
-- Name: gvalues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE gvalues (
    gid integer,
    dist numeric
);


ALTER TABLE gvalues OWNER TO postgres;

--
-- Data for Name: distances; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2796.dat

--
-- Data for Name: gvalues; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2795.dat

--
-- PostgreSQL database dump complete
--

